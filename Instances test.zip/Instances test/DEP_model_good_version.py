
" Thay doi fonction objective so voi v002 = them vao yield rate"


from gurobipy import *
import os
import xlrd
import time
from functools import wraps

#record starting time
start_time = time.time()
"how to read data from xlsx to multidict data_S10_P5_R1_Sce200_de1.xls"
#book = xlrd.open_workbook(os.path.join("C:\\Users\\nguyendu\\Desktop","Simple01.xls"))
filename="data_S80_P5_R1_Sce1_de1.xls"
book = xlrd.open_workbook(filename)
print(filename)
print(1222)
pcost=1.06
"scenarios"
scenarios=[]
sh = book.sheet_by_name("Scenario")
i=1
while True:
        try:
            a=round(sh.cell_value(i, 0))
            scenarios.append(a)          
            i = i + 1
        except IndexError:
            break

probability={}
contract={}
for s in scenarios:
    probability[s]=1/(len(scenarios))
"Multidict arcs"
sh = book.sheet_by_name("Arcs")
arcs=[]
distance={}
CapV={}
Vcost={}
i=1
while True:
        try:
            a=sh.cell_value(i, 0),sh.cell_value(i,1)
            arcs.append(a)            
            
            value_capV=sh.cell_value(i,4)
            CapV[a]=value_capV
            
            value_Vcost=sh.cell_value(i,5)
            Vcost[a]=value_Vcost
            i = i + 1
        except IndexError:
            break
        
arcs = tuplelist(arcs)        
"Multidict supplier"
sh = book.sheet_by_name("supplier")

supplier=[]
costA_I={}
mcost={}
Q_min_contract={}
i=1
while True:
        try:
            a=sh.cell_value(i, 0)
            supplier.append(a)
            costA_I[a]=sh.cell_value(i, 1)
            mcost[a]=sh.cell_value(i, 2)
            Q_min_contract[a]=round(sh.cell_value(i, 3))
            i=i+1
        except IndexError:
            break 
        


"Multidict market"
sh = book.sheet_by_name("Market")
market=[]
costA_M={}
i=1
while True:
        try:
            a=sh.cell_value(i, 0)
            market.append(a)
            costA_M[a]=sh.cell_value(i, 1)
            i=i+1
        except IndexError:
            break 

"Multidict pretraitement"
sh = book.sheet_by_name("Pretraitement")
pretraitement=[]
W_initial,W_min, W_max, gamma_min_P={},{},{},{}
gamma_max_P,  eta_P, lamda_P, hcost_P, tcost_P={},{},{},{},{}
i=1
while True:
        try:
            a=sh.cell_value(i, 0)
            pretraitement.append(a)
            W_initial[a]=sh.cell_value(i, 1)
            W_min[a]=sh.cell_value(i, 2)
            W_max[a]=sh.cell_value(i, 3)
            gamma_min_P[a]=sh.cell_value(i, 4)
            gamma_max_P[a]=sh.cell_value(i, 5)
            eta_P[a]=sh.cell_value(i, 6)
            lamda_P[a]=sh.cell_value(i, 7)
            hcost_P[a]=sh.cell_value(i, 8)
            tcost_P[a]=sh.cell_value(i, 9)
            i=i+1
        except IndexError:
            break         
        
"Multidict refinery"
sh = book.sheet_by_name("Refinery")
refinery=[]
V_av_initial, V_av_min, V_av_max, V_ap_initial,V_ap_min, V_ap_max={},{},{},{},{},{}
eta_B, lamda_B, tcost_B, hcost_B_av, hcost_B_ap, gamma_min_B, gamma_max_B={},{},{},{},{},{},{}
i=1
while True:
        try:          
            a=sh.cell_value(i, 0)
            refinery.append(a)
            V_av_initial[a]=sh.cell_value(i, 1)
            V_av_min[a]=sh.cell_value(i, 2)
            V_av_max[a]=sh.cell_value(i, 3)
            V_ap_initial[a]=sh.cell_value(i, 4)
            V_ap_min[a]=sh.cell_value(i, 5)
            V_ap_max[a]=sh.cell_value(i, 6)
            eta_B[a]=sh.cell_value(i, 7)
            lamda_B[a]=sh.cell_value(i, 8)
            tcost_B[a]=sh.cell_value(i, 9)
            hcost_B_av[a]=sh.cell_value(i, 10)
            hcost_B_ap[a]=sh.cell_value(i, 11)
            gamma_min_B[a]=sh.cell_value(i, 12)
            gamma_max_B[a]=sh.cell_value(i, 13)
            i=i+1
        except IndexError:
            break         


"dict demand"
sh = book.sheet_by_name("Demand")
demand={}
i=2
j=1
for i in range(2,sh.nrows):     
    for j in range(1,sh.ncols):
        a=sh.cell_value(i, 0), sh.cell_value(1, j)
        demand[a]=round(sh.cell_value(i, j))
        
"dict avai_M" " period data"
sh = book.sheet_by_name("Avail_market")
avail_M={}
period=[]
i=2
j=1
for j in range(1,sh.ncols):
    b=round(sh.cell_value(1, j))
    period.append(b)     
    for i in range(2,sh.nrows):
        a=sh.cell_value(i, 0)
        b=round(sh.cell_value(1, j))
        avail_M[a,b]=round(sh.cell_value(i, j))
                
                
"dict avai_I the availability of supplier in different scenarios"

avail_I={}
for s in scenarios:
    sh = book.sheet_by_name('Avail_scenario_%s'% s)
    for i in range(2,sh.nrows):     
        for j in range(1,sh.ncols):
            a=sh.cell_value(i, 0)
            b=round(j)
            avail_I[a,b,s]=round(sh.cell_value(i, j))
#print(avail_I)            
market= list(market)
arcs = tuplelist(arcs)            
pretraitement = list(pretraitement)
refinery = list(refinery)


m = Model('biomassSC')
#m.setParam( 'OutputFlag', 0 )
m.params.MIPGap=0.00001
#m.params.threads = 1
m.modelSense = GRB.MINIMIZE
#m.params.Heuristics=0 
##m.params.timeLimit = 1800
m.params.Presolve=0 
#m.params.InfUnbdInfo = 1
#m.params.NodefileStart = 0.5
#m.params.DualReductions = 0
##m.params.MIPFocus=3 
#m.params.Cuts=0
#m.setParam('OutputFlag', False) # turns off solver chatter

# Create variables

# Transport variable
flow = {} #flow entre noeud i et j à la periode t
#nbrT = {} #nbr de tour (camions) entre noeud i et j à la periode t
W = {} # Niveau de stock pour le pretraitement p à la period t
V_av = {} # Niveau de stock (avant la transformation en biocarburant) pour la bioraffinerie b à la period t
V_ap = {} # Niveau de stock (apres la transformation en biocarburant)pour la bioraffinerie b à la period t
z = {} # Quantite utilisee lors de la transformation en biocarburant pour la bioraffinerie b à la period t
Y = {}   #Niveau de stock à la fournisseur i
Q_I = {} #Quantite totale à délivrer à partir du fournisseur i à la periode t
Q_P = {} #Quantite de transformation au pretraitement p
contract = {} # contract long terme avec le fournisseur i
shortage = {} 
demandS = {} # La partie satisfaite à la demande pour la bioraffinerie b a la periode t
x_MB, nbrT = {},{}

##variable contract[i] est fixee (connue)---> parametre dans ce problem
for i in supplier:
    contract[i] = m.addVar(vtype=GRB.BINARY, obj=mcost[i], name='contract %s' % (i))
    
    
for s in scenarios:
    for t in period:
        for l in market:
            for b in refinery:
                x_MB[l, b, t,s]= m.addVar(obj=costA_M[l]*probability[s],name='x_MB_%s_%s_%s_%s' % (l, b, t, s))
    
    
    for t in period:        
        for i, j in arcs:
            flow[i, j, t,s] = m.addVar(name='flow_%s_%s_%s_%s' % (i, j, t,s))
            nbrT[i, j, t,s] = m.addVar(vtype=GRB.INTEGER,obj=Vcost[i, j], name='nbrT_%s_%s_%s_%s' % (i, j, t,s) )

        for i in supplier:
            #Y[i, t] = m.addVar(ub=Y_max[i], name='inventory_supplier %s_%s' % (j, t))
            Q_I[i, t,s] = m.addVar(obj=costA_I[i]*probability[s], name='Quantity_total_supplier %s_%s_%s' % (i, t,s))
    
        for j in pretraitement:
            W[j, t,s] = m.addVar(  lb=W_min[j] ,       ub=W_max[j],       obj=hcost_P[j]*probability[s],       name='inventory_pre %s_%s_%s' % (j, t,s))
            Q_P[j, t,s] = m.addVar(lb=gamma_min_P[j] , ub=gamma_max_P[j], obj=eta_P[j]*tcost_P[j]*probability[s], name='Q_P %s_%s_%s' % (j, t,s))
    
        for h in refinery:
            V_av[h, t,s] = m.addVar(lb=V_av_min[h],    ub=V_av_max[h],    obj=hcost_B_av[h]*probability[s],    name='inventory_bio %s_%s_%s' % (h, t,s))
            V_ap[h, t,s] = m.addVar(lb=V_ap_min[h],    ub=V_ap_max[h],    obj=hcost_B_ap[h]*probability[s],  name='inventory_bio %s_%s_%s' % (h, t,s))
            z[h, t,s] = m.addVar(lb=gamma_min_B[h],    ub=gamma_max_B[h], obj=eta_B[h]*tcost_B[h]*probability[s] ,name='Q_prod %s_%s_%s' % (h, t,s))
            shortage[h,t,s] = m.addVar(obj=pcost*probability[s],name='shortage %s_%s_%s' % (h,t,s))


m.update()


# inventory level constraints
'balance flows constraint'
for s in scenarios:
    for i in supplier:
        # supply constraint (0.0.3)
        m.addConstr(quicksum(Q_I[i, t,s] for t in period) >= Q_min_contract[i]*contract[i])
        
for s in scenarios:        
    for t in period:
        for i in supplier:
                # supply constraint (0.0.1)            
                m.addConstr(Q_I[i, t,s] == sum(flow[i,p,t,s] for i, p in arcs.select(i,'*')))
                # supply constraint (0.0.2)
                m.addConstr(Q_I[i, t,s] <= avail_I[i, t,s] * contract[i]) 
    
                #m.addConstr(Q_I[i, t])<= 10000000*contract[i] )
    'supply market'
for s in scenarios:    
    for t in period:
        for l in market:
            # biomass market constraint (0.0.4)
            m.addConstr(sum(x_MB[l,b,t,s] for b in refinery) <= avail_M[l,t])
    
    
    
    'inventory level constraints'
for s in scenarios:    
    # inventory level in pretraitment facility constraint (0.0.7)
    for j in pretraitement:
        m.addConstr(W[j, 1,s] == lamda_P[j]*W_initial[j]+ eta_P[j]*Q_P[j,1,s]
                                           - sum(flow[j, h, 1,s] for j, h in arcs.select(j, '*')))
    
for s in scenarios:
    # inventory pretraitment constraint (0.0.6) 
    for t in period:
        if t >=2:
            for j in pretraitement:
                m.addConstr(W[j, t,s] == lamda_P[j]*W[j, t-1,s]+ eta_P[j]*Q_P[j,t,s]
                                            - sum(flow[j, h, t,s] for j, h in arcs.select(j, '*')))

for s in scenarios:    
    # Production capacity of pretraitement facility (0.0.5)
    for t in period:
        for p in pretraitement:
            m.addConstr(sum(flow[i, p, t,s] for i, p in arcs.select('*', p)) == Q_P[p,t,s])
          
    
for s in scenarios:   
     # biomass inventory level in bioraffinerie constraints (0.0.11)
    for h in refinery:
        m.addConstr(V_av[h, 1,s] ==lamda_B[h]*V_av_initial[h] 
                                    + sum(flow[j, h, 1,s] for j, h in arcs.select('*', h)) - z[h,1,s]
                                    + sum(x_MB[m,h,1,s] for m in market))
    
for s in scenarios:
    # biomass inventory level in bioraffinerie constraints (0.0.10)
    for t in period:
        if t >=2:
            for h in refinery:
                m.addConstr(V_av[h, t,s] == lamda_B[h]*V_av[h, t - 1,s]
                                        + sum(flow[j, h, t,s] for j, h in arcs.select('*', h)) - z[h, t,s]
                                        + sum(x_MB[m,h,t,s] for m in market))
 
for s in scenarios:          
    # biofuel inventory level constraints (13)      
    for h in refinery:
        m.addConstr(V_ap[h, 1,s] == V_ap_initial[h]+ eta_B[h]*z[h, 1, s] 
                                                - demand[h, 1] + shortage[h, 1, s])
    

for s in scenarios:
    # biofuel inventory level constraints (12)  
    for t in period:
        if t >=2:
            for h in refinery:   
                m.addConstr(V_ap[h, t,s] == V_ap[h, t - 1,s] + eta_B[h]*z[h, t,s]
                                                    - demand[h, t] + shortage[h,t,s])
            
for s in scenarios:
    for t in period:
        for i,j in arcs:
            m.addConstr(flow[i, j, t,s] <= nbrT[i,j,t,s]* CapV[i, j])
           
# Objective function

# Compute optimal solution
#m.write("model2.lp")
m.optimize()
print ('OBJ of DEP problem= %s'% m.ObjVal)
contract = m.getAttr('x', contract)
print('n° of contracts is %s'% sum(contract[i] for i in supplier))
#for i in supplier:
#    if contract[i]> 0:
#        print('contract with supplier %s'% i)


x_MB = m.getAttr('x', x_MB)
flow=m.getAttr('x', flow)
shortage=m.getAttr('x', shortage)
nbrT=m.getAttr('x', nbrT)
#print(x_MB)


#Measure computation timeOptimize a model with 442 rows, 478 columns and 1081 nonzeros


print('elapsed_time=%s'% (time.time() - start_time) )           